# Tesla Türkiye ikinci el Model Y takipçisi

Bu proje Tesla'nın verdiğiniz resmi ikinci el Model Y envanterini 5 dakikada bir kontrol eder ve daha önce görülmemiş VIN'ler için Gmail bildirimi gönderir.

## GitHub'a kurulum

1. GitHub'da `tesla-used-inventory-monitor` adında **Private** bir repository oluşturun.
2. Bu ZIP içeriğini repository'nin kök dizinine yükleyin; `.github/workflows/monitor.yml` yolu korunmalı.
3. Repository > Settings > Secrets and variables > Actions > New repository secret bölümünde şu 3 secret'ı tanımlayın:
   - `GMAIL_ADDRESS`: Gönderici Gmail adresiniz
   - `GMAIL_APP_PASSWORD`: Google 2 adımlı doğrulama açıkken oluşturulan 16 karakterlik uygulama şifresi
   - `MAIL_TO`: `a.burakcanakci@gmail.com`
4. Settings > Actions > General > Workflow permissions bölümünde **Read and write permissions** seçin.
5. Actions sekmesinden `Tesla used Model Y inventory monitor` iş akışını seçip **Run workflow** ile ilk çalıştırmayı başlatın.
6. İlk başarılı çalışma mevcut VIN listesini başlangıç referansı olarak kaydeder; mevcut araçlar için toplu e-posta göndermez. Sonraki taramalarda yeni VIN bulunursa e-posta gönderir.

## Gmail uygulama şifresi

Google hesabınızda 2 Adımlı Doğrulama'yı açın. Google Hesabı > Güvenlik > Uygulama şifreleri bölümünden bir uygulama şifresi üretin. Normal Gmail parolanızı GitHub'a koymayın. Uygulama şifresini yalnızca `GMAIL_APP_PASSWORD` secret'ına ekleyin.

## Önemli notlar

- GitHub Actions cron zamanlaması 5 dakikalık aralığı destekler; yoğunluk nedeniyle tam dakikasında çalışması garanti edilmez.
- Tesla'nın envanter API'si herkese açık, kararlı bir API/SLA değildir. Tesla uç noktayı veya alan adlarını değiştirebilir ya da otomatik istekleri engelleyebilir. Actions loglarını kontrol edin.
- İstekler sadece her 5 dakikada bir yapılır. Erişim engeli aşmak için yüksek sıklık veya proxy kullanmayın.
- İlk çalışma başlangıç envanterini referans alır; böylece mevcut tüm ilanlar yeni ilanmış gibi bildirilmez.
- Bildirimde VIN, model/yıl, kilometre, fiyat ve Tesla envanter bağlantısı yer alır. Tesla API alanları değişirse bazı alanlar boş/ham gelebilir.
- Bu bot araç ayırtmaz veya satın alma işlemi yapmaz. İlanı Tesla sayfasında ayrıca doğrulayın.
