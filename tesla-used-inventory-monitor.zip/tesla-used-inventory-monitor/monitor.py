import json
import os
import smtplib
import sys
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import quote

import requests

INVENTORY_PAGE = (
    "https://www.tesla.com/tr_TR/inventory/used/my"
    "?arrangeby=plh&zip=34080&HasVehiclePhotos=true"
)
API_URL = "https://www.tesla.com/coinorder/api/v4/inventory-results"
STATE_PATH = Path("data/seen_vins.json")
ZIP_CODE = os.getenv("TESLA_ZIP", "34080")
RECIPIENT = os.environ["MAIL_TO"]
SENDER = os.environ["GMAIL_ADDRESS"]
APP_PASSWORD = os.environ["GMAIL_APP_PASSWORD"].replace(" ", "")

def fetch_inventory():
    query = {
        "query": {
            "model": "my",
            "condition": "used",
            "options": {},
            "arrangeby": "Price",
            "order": "asc",
            "market": "TR",
            "language": "tr",
            "super_region": "north america",
            "lng": "",
            "lat": "",
            "zip": ZIP_CODE,
            "range": 0,
        },
        "offset": 0,
        "count": 100,
        "outsideOffset": 0,
        "outsideSearch": False,
        "isFalconDeliverySelectionEnabled": True,
        "version": "v2",
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; PersonalInventoryMonitor/1.0)",
        "Accept": "application/json, text/plain, */*",
        "Referer": INVENTORY_PAGE,
    }
    response = requests.get(
        API_URL, params={"query": json.dumps(query, separators=(",", ":"))},
        headers=headers, timeout=35
    )
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict) or not isinstance(data.get("results"), list):
        raise RuntimeError("Tesla API response did not contain a valid results list")
    return data["results"], data.get("total_matches_found")

def get_vin(car):
    return car.get("VIN") or car.get("vin") or car.get("VehicleId")

def format_car(car):
    vin = get_vin(car)
    year = car.get("Year", car.get("year", "Belirtilmemiş"))
    trim = car.get("TrimName") or car.get("trim") or car.get("Model") or "Model Y"
    price = car.get("InventoryPrice", car.get("Price", car.get("price", "Belirtilmemiş")))
    km = car.get("Odometer", car.get("odometer", "Belirtilmemiş"))
    km_unit = car.get("OdometerType", "km")
    exterior = car.get("PAINT") or car.get("ExteriorColor") or car.get("Paint") or "Belirtilmemiş"
    url = f"https://www.tesla.com/tr_TR/my/order/{vin}?postal={ZIP_CODE}&titleStatus=used" if vin else INVENTORY_PAGE
    return (
        f"Model/Yıl: {trim} / {year}\n"
        f"Fiyat: {price} TL (Tesla API ham değeri)\n"
        f"Kilometre: {km} {km_unit}\n"
        f"Renk: {exterior}\n"
        f"VIN: {vin or 'Belirtilmemiş'}\n"
        f"İlan: {url}\n"
    )

def send_email(new_cars):
    msg = EmailMessage()
    msg["Subject"] = f"Tesla ikinci el Model Y: {len(new_cars)} yeni ilan bulundu"
    msg["From"] = SENDER
    msg["To"] = RECIPIENT
    body = [
        "Tesla Türkiye ikinci el Model Y envanterinde yeni ilan tespit edildi.",
        f"Envanter: {INVENTORY_PAGE}",
        "",
    ]
    body.extend(format_car(car) + "\n" for car in new_cars)
    msg.set_content("\n".join(body))
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as smtp:
        smtp.login(SENDER, APP_PASSWORD)
        smtp.send_message(msg)

def main():
    cars, total = fetch_inventory()
    cars_by_vin = {get_vin(car): car for car in cars if get_vin(car)}
    current_vins = set(cars_by_vin)

    # First successful run creates a baseline; it does not email all existing stock.
    if STATE_PATH.exists():
        state = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        seen = set(state.get("seen_vins", []))
        new_vins = current_vins - seen
        if new_vins:
            send_email([cars_by_vin[vin] for vin in sorted(new_vins)])
            print(f"Sent email for {len(new_vins)} new vehicle(s).")
        else:
            print("No new vehicles.")
        seen.update(current_vins)
    else:
        seen = current_vins
        print(f"Initial baseline saved ({len(seen)} vehicle(s)); no alert sent.")

    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(
        json.dumps({"seen_vins": sorted(seen)}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Tesla API total_matches_found={total}; received={len(cars)}")

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"MONITOR ERROR: {exc}", file=sys.stderr)
        raise
